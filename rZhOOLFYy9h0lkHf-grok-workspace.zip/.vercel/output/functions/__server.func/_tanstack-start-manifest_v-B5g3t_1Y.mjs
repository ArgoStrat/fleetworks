//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B5g3t_1Y.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CgL0yA8w.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CgL0yA8w.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BDR9JhOe.js"]
	}
} });
//#endregion
export { tsrStartManifest };
