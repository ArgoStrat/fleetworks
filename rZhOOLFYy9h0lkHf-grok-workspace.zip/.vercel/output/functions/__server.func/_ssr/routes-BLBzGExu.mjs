import { i as __toESM } from "../_runtime.mjs";
import { n as useForm, r as require_react, t as u } from "../_libs/@hookform/resolvers+[...].mjs";
import { _ as require_jsx_runtime, a as Trigger2, i as Root2, n as Header, p as Slot, r as Item, t as Content2 } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { a as Pause, c as Check, i as Phone, l as ArrowRight, o as Menu, r as Play, s as ChevronDown, t as X } from "../_libs/lucide-react.mjs";
import { a as object, n as email, o as string, t as _enum } from "../_libs/zod.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BLBzGExu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-3 focus-visible:outline-accent disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent-fg)_10%,transparent)] hover:brightness-105",
			secondary: "bg-elevated text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "bg-transparent text-fg hover:bg-elevated",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-elevated"
		},
		size: {
			sm: "h-9 rounded-sm px-3.5 text-sm",
			md: "h-11 rounded-md px-5 text-[0.9375rem]",
			lg: "h-12 rounded-md px-5 text-base"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var useApp = create((set) => ({
	audience: "carrier",
	setAudience: (audience) => set({ audience }),
	leadOpen: false,
	leadSource: "hero",
	openLead: (source = "hero") => set({
		leadOpen: true,
		leadSource: source
	}),
	closeLead: () => set({ leadOpen: false })
}));
var options = [{
	id: "carrier",
	label: "Carriers"
}, {
	id: "broker",
	label: "Brokers"
}];
function AudienceToggle({ className }) {
	const audience = useApp((s) => s.audience);
	const setAudience = useApp((s) => s.setAudience);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "tablist",
		"aria-label": "Choose audience",
		className: cn("relative grid grid-cols-2 rounded-md bg-elevated p-1 shadow-[var(--shadow-border)]", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": true,
			className: "absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-sm bg-accent transition-transform duration-250 ease-[cubic-bezier(0.22,1,0.36,1)]",
			style: { transform: audience === "broker" ? "translateX(calc(100% + 2px))" : "translateX(2px)" }
		}), options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			role: "tab",
			"aria-selected": audience === opt.id,
			onClick: () => setAudience(opt.id),
			className: cn("relative z-10 h-9 px-3 font-display text-sm font-semibold tracking-tight transition-colors duration-150", audience === opt.id ? "text-accent-fg" : "text-muted"),
			children: opt.label
		}, opt.id))]
	});
}
var PHONE_DISPLAY = "(872) 328-5278";
var PHONE_TEL = "+18723285278";
var CARRIER_EMAIL = "carrier-ops@fleetworks.ai";
var navLinks = [
	{
		href: "#how",
		label: "How it works"
	},
	{
		href: "#proof",
		label: "Proof"
	},
	{
		href: "#product",
		label: "Product"
	},
	{
		href: "#faq",
		label: "FAQ"
	}
];
var hero = {
	carrier: {
		eyebrow: "Load board on autopilot",
		headline: "Stop refreshing. Start driving.",
		sub: "We call the brokers. We negotiate the rate. You get a short list of loads that actually fit your truck — and you still pick every one.",
		primary: "Get my first load offers",
		secondary: "Hear a live negotiation"
	},
	broker: {
		eyebrow: "Carrier sales on autopilot",
		headline: "Cover the load before the board does.",
		sub: "AI agents call, text, and email 29,000+ vetted carriers against your buy rates and live SONAR market data. Your reps only touch the conversations worth a human.",
		primary: "Book a coverage walkthrough",
		secondary: "See a load get covered"
	}
};
var proofStats = [
	{
		value: "29,000+",
		label: "vetted carrier MCs"
	},
	{
		value: "40+",
		label: "U.S. brokerages"
	},
	{
		value: "15",
		label: "of the top 100 brokers"
	},
	{
		value: "30,000+",
		label: "loads touched daily"
	}
];
var investors = [
	"Y Combinator",
	"First Round",
	"LFX Venture Partners",
	"Saga Ventures",
	"Liquid 2 Ventures"
];
var problem = {
	carrier: {
		kicker: "The hidden tax on every mile",
		title: "You didn't buy a truck to sit on DAT.",
		body: "Carriers lose hours every day chasing freight — refreshing boards, sitting on hold, re-explaining equipment, and still missing the load that moved 11 minutes ago. A human dispatcher takes 5–10% of linehaul to do the same work, on a clock that ends at 5.",
		points: [
			{
				title: "Hold music is not a strategy",
				body: "By the time you reach a broker, the good freight is gone. The board doesn't call you back."
			},
			{
				title: "The 10% cut is a quiet leak",
				body: "On a $3,000 load, that's $150–$300 that never hits your account. Over a year it funds another truck."
			},
			{
				title: "Preferences get forgotten",
				body: "Home time, bad facilities, favorite lanes — most dispatchers reset every Monday. Yours shouldn't."
			}
		]
	},
	broker: {
		kicker: "Coverage is a phone problem",
		title: "A hundred calls to move one truckload.",
		body: "Carrier sales reps burn the day on voicemail, tire-kickers, and rate shopping. Track-and-trace chases the 28% GPS never sees. Margins stay in the low single digits because 70% of the work is repetition a person shouldn't be doing.",
		points: [
			{
				title: "Boards are a race you already lost",
				body: "Posting to DAT is an auction. The first qualified truck that actually picks up the phone wins — and it isn't always yours."
			},
			{
				title: "Reps cap out at 20–30 loads a day",
				body: "Paul Singer, our CEO: with FleetWorks, those same reps already clear 75+. The ceiling is 200."
			},
			{
				title: "The 28% you can't see",
				body: "GPS gets you to ~72% location compliance. The rest is a person making tracking calls. One customer killed ~750 of those a month."
			}
		]
	}
};
var how = {
	carrier: [
		{
			step: "01",
			title: "Tell us the truck",
			body: "Lanes, equipment, home time, facilities you'll never touch again. One conversation. We remember it."
		},
		{
			step: "02",
			title: "We work the brokers",
			body: "FleetWorks calls and emails your lanes around the clock, negotiates against live market, and only brings you bookable offers."
		},
		{
			step: "03",
			title: "You pick. Then you pull.",
			body: "Accept from your phone. A U.S. relationship manager is a call or text away if anything gets weird."
		}
	],
	broker: [
		{
			step: "01",
			title: "Plug in the load",
			body: "TMS sync pulls commodity, equipment, buy rates, and stop notes. You set guardrails. We stay inside them."
		},
		{
			step: "02",
			title: "Agents work the network",
			body: "Voice, SMS, and email hit carriers who are actually empty nearby. Highway and Carrier411 vetting happens in the conversation."
		},
		{
			step: "03",
			title: "Humans take the close",
			body: "Qualified carriers land in Offer Manager. Out-of-market situations escalate with SONAR context already attached."
		}
	]
};
var features = {
	carrier: [
		{
			title: "Negotiated offers, not listings",
			body: "You don't scroll a board. You get a rate someone already said yes to, matched to your truck."
		},
		{
			title: "It remembers the freight you want",
			body: "Favorite lanes, equipment, and the docks that waste a day — updated every time you talk to us."
		},
		{
			title: "Problems get worked before they sit",
			body: "Live issues get flagged. We call the broker or shipper so you keep rolling instead of waiting on a voicemail."
		},
		{
			title: "A person on your side",
			body: "Every carrier gets a dedicated U.S.-based relationship manager. Call or text (872) 328-5278 anytime."
		}
	],
	broker: [
		{
			title: "AI carrier sales",
			body: "Outbound and inbound on voice, SMS, and email. MC lookup, compliance, rate negotiation, warm transfer with full context."
		},
		{
			title: "Capacity that isn't a load board",
			body: "29,000+ carriers self-reporting empty location and equipment. Offer Manager turns inbound bids into one approve/negotiate queue."
		},
		{
			title: "Track & trace that finishes the 28%",
			body: "GPS first. Then agents call, text, and email until the location is real — without a person dialing."
		},
		{
			title: "SONAR inside the conversation",
			body: "Lane-level TRAC rates and coverage scores sit in the same call as the negotiation. No tab-switching. No stale averages."
		}
	]
};
var results = {
	carrier: [
		{
			stat: "5–10%",
			label: "dispatcher cut you stop writing off",
			note: "On a $3,000 load that's $150–$300 back on your side of the table."
		},
		{
			stat: "24/7",
			label: "coverage while you sleep or drive",
			note: "The agent doesn't take lunch. Empty time is the enemy. We hunt it."
		},
		{
			stat: "1",
			label: "U.S. relationship manager, not a ticket queue",
			note: "A real person who knows your lanes. Phone, text, or email."
		}
	],
	broker: [
		{
			stat: "4%",
			label: "load-margin expansion, customer-reported",
			note: "Because every conversation prices against live market, not last week's gut."
		},
		{
			stat: "10%",
			label: "faster booking velocity",
			note: "Procurement cost down ~1%. Low-quality inbound calls down 45% in one shop."
		},
		{
			stat: "75+",
			label: "loads per rep per day, already happening",
			note: "Pre-AI, a strong rep did 20–30. The design target is 200."
		}
	]
};
var stories = [
	{
		quote: "FleetWorks always helps bring good loads as soon as they're available.",
		name: "Deepashu",
		role: "Owner, Leo Transportation"
	},
	{
		quote: "FleetWorks does a good job remembering my preferences and sending freight that matches.",
		name: "Nike",
		role: "Owner, The Right Price Delivery"
	},
	{
		quote: "If you're used to calling brokers to find freight, this is the same thing — but they call for you.",
		name: "Andre",
		role: "Owner, Phinix Logistics"
	},
	{
		quote: "I love it. You guys make it so easy to find loads.",
		name: "Ramandee",
		role: "Owner, R&G Cargo"
	},
	{
		quote: "FleetWorks is very helpful in finding you a load. They always ask the right questions.",
		name: "Jermain",
		role: "Owner, J&J Transit"
	}
];
var offer = {
	carrier: {
		title: "Keep the linehaul. Let the agent do the calling.",
		body: "Traditional dispatchers take 5–10% of every load. FleetWorks is built so you don't have to fund a person to refresh a board. You still choose every load. Pricing is set on a call with ops — no surprise cut on settlement.",
		bullets: [
			"You approve every book. Nothing moves without you.",
			"Brokers on the network are screened for credit and on-time pay.",
			"Dedicated U.S. relationship manager included."
		],
		cta: "Talk to carrier ops"
	},
	broker: {
		title: "Pay for coverage. Not for hold music.",
		body: "FleetWorks is priced to your volume and which agents you run — carrier sales, track & trace, or both. No public seat-tax. We walk the math against your current cost per covered load.",
		bullets: [
			"You set buy-rate guardrails. We do not freelance on price.",
			"Out-of-market negotiations escalate to a human with SONAR attached.",
			"TMS-native. Aljex / Descartes and others already in production."
		],
		cta: "Book the walkthrough"
	}
};
var faqs = {
	carrier: [
		{
			q: "Do I still choose the load?",
			a: "Always. FleetWorks negotiates and brings you offers. Nothing is booked until you say yes."
		},
		{
			q: "What does it cost?",
			a: "We don't take a traditional 5–10% dispatcher cut of linehaul. Exact terms are set with carrier ops on a short call so they match how you run — owner-operator, small fleet, or dedicated lanes."
		},
		{
			q: "Can I talk to a person?",
			a: `Yes. Every carrier gets a dedicated U.S.-based relationship manager. Call or text ${PHONE_DISPLAY} or email ${CARRIER_EMAIL} any time.`
		},
		{
			q: "Which brokers will I actually haul for?",
			a: "The network includes 40+ U.S. brokerages, among them 15 of the top 100 — names like Ally Logistics, Sage Freight, and KCH Transportation. Every broker is screened for credit and a record of paying carriers on time."
		},
		{
			q: "What if a problem hits in transit?",
			a: "The same agent that found the load watches for live issues and reaches the broker or shipper so you're not the only one on the phone."
		}
	],
	broker: [
		{
			q: "Do we lose control of the rate?",
			a: "No. You set min/max buy rates, approval thresholds, and escalation rules. The agent negotiates inside those rails. If the market is outside them, it hands a human the call with SONAR context already on the thread."
		},
		{
			q: "How do you keep bad actors off the freight?",
			a: "MC lookup and compliance run in the conversation via Highway and Carrier411. Voice and photo verification, insurance checks, and custom rules per load, shipper, or lane sit on top of that baseline."
		},
		{
			q: "Will this replace my carrier sales team?",
			a: "It makes them faster. Pre-AI a strong rep covered 20–30 loads a day. With FleetWorks, those same people already clear 75+. They keep the relationship and the exceptions. The agent does the repetitive outreach."
		},
		{
			q: "What about our TMS?",
			a: "Loads, notes, and rate ranges sync from the TMS. Descartes Aljex is a public integration. Tracking updates and booked carriers write back so ops isn't copy-pasting from a chat window."
		},
		{
			q: "Where does SONAR show up?",
			a: "Inside the live negotiation — phone, email, and SMS. TRAC rates and coverage scores price the conversation against today's lane, not last week's average."
		}
	]
};
var demoTurns = {
	carrier: [
		{
			who: "ai",
			name: "Maya · FleetWorks",
			text: "Got a 53' dry van, Joliet empty at 06:00. Chicago to Dallas, pickup tomorrow 08:00. Asking what you're paying."
		},
		{
			who: "them",
			name: "Broker · Midwestern desk",
			text: "I can do $2,400 all-in. That's the board."
		},
		{
			who: "ai",
			name: "Maya · FleetWorks",
			text: "SONAR's at $2.18 a mile on that lane — $2,650 all-in. Driver's a regular on this, clean inspection, on-time at that shipper. Can you do $2,575?"
		},
		{
			who: "them",
			name: "Broker · Midwestern desk",
			text: "Two-five-fifty and I'll send the rate con in the next ten."
		},
		{
			who: "ai",
			name: "Maya · FleetWorks",
			text: "Locked at $2,550. Sending the offer to the carrier now — they still have to accept. I'll confirm in a minute."
		}
	],
	broker: [
		{
			who: "ai",
			name: "Maya · FleetWorks",
			text: "Load 48291, Chicago–Dallas dry van, buy max $2,600. Calling carriers empty inside 75 miles. First up: Phinix, 53' sitting in Joliet."
		},
		{
			who: "them",
			name: "Andre · Phinix Logistics",
			text: "Yeah we can pick at 08:00. I need $2,700 on that lane."
		},
		{
			who: "ai",
			name: "Maya · FleetWorks",
			text: "Market's $2.18. I can do $2,550 inside the desk's rail. Detention starts at two hours, easy in, no lumper. Work for you?"
		},
		{
			who: "them",
			name: "Andre · Phinix Logistics",
			text: "Two-five-fifty if you send it in the next ten and the receiver isn't that South Dallas dock."
		},
		{
			who: "ai",
			name: "Maya · FleetWorks",
			text: "Receiver's the North facility. Pushing you to Offer Manager for a one-tap approve. Context and SONAR snapshot attached."
		}
	]
};
var ctaBand = {
	carrier: {
		title: "Your next empty should already have an offer on it.",
		body: "Tell us the truck. We'll start calling. You keep the right to say no.",
		primary: "Get my first load offers"
	},
	broker: {
		title: "Put an extra carrier rep on every desk tonight.",
		body: "A 30-minute walkthrough. Your lanes, your rails, your TMS. No slideware.",
		primary: "Book a coverage walkthrough"
	}
};
function copyFor(audience) {
	return {
		hero: hero[audience],
		problem: problem[audience],
		how: how[audience],
		features: features[audience],
		results: results[audience],
		offer: offer[audience],
		faqs: faqs[audience],
		demo: demoTurns[audience],
		cta: ctaBand[audience]
	};
}
function Hero() {
	const audience = useApp((s) => s.audience);
	const openLead = useApp((s) => s.openLead);
	const copy = copyFor(audience);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "top",
		className: "relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/hero-highway.jpg",
					alt: "Class 8 tractor on a wet interstate at blue hour",
					className: "h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-bg via-bg/80 to-bg/35" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-transparent to-bg/40" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto grid min-h-[calc(100svh-4rem)] max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-in max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-5 flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudienceToggle, { className: "w-56 md:hidden" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
							children: copy.hero.eyebrow
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-[2.5rem] leading-[1.08] font-semibold tracking-[-0.03em] sm:text-5xl lg:text-[3.35rem]",
						children: copy.hero.headline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-[38rem] text-lg leading-relaxed text-muted",
						children: copy.hero.sub
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "lg",
							onClick: () => openLead("hero"),
							children: [copy.hero.primary, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							variant: "secondary",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#demo",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {}), copy.hero.secondary]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-10 grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-4",
						children: proofStats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-display text-xl font-semibold tracking-tight",
							children: s.value
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-0.5 text-xs leading-snug text-muted",
							children: s.label
						})] }, s.label))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveCard, {})]
		})]
	});
}
function LiveCard() {
	const audience = useApp((s) => s.audience);
	const openLead = useApp((s) => s.openLead);
	if (audience === "broker") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-xl bg-surface/90 p-5 shadow-[var(--shadow-border)] backdrop-blur-sm sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2 font-mono text-[0.7rem] tracking-[0.16em] text-accent uppercase",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-accent animate-[pulse-dot_1.6s_ease-in-out_infinite]" }), "Covering now"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-muted",
					children: "LOAD 48291"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 font-display text-2xl font-semibold tracking-tight",
				children: "CHI → DAL"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "53' dry van · pickup tomorrow 08:00"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid grid-cols-3 gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-elevated p-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: "Buy max"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-display text-lg font-semibold",
							children: "$2,600"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-elevated p-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: "SONAR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-display text-lg font-semibold",
							children: "$2.18"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-elevated p-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: "On the line"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-display text-lg font-semibold",
							children: "3"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-md bg-elevated px-3 py-3 text-sm leading-relaxed text-muted",
				children: "Maya (AI) on with Phinix Logistics. Counter at $2,550. Highway clear. Warm transfer ready."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-5 w-full",
				onClick: () => openLead("hero-card"),
				children: "Put this on my desk"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-xl bg-surface/90 p-5 shadow-[var(--shadow-border)] backdrop-blur-sm sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2 font-mono text-[0.7rem] tracking-[0.16em] text-accent uppercase",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-accent animate-[pulse-dot_1.6s_ease-in-out_infinite]" }), "Negotiated offer"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-muted",
					children: "2 min ago"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 font-display text-2xl font-semibold tracking-tight",
				children: "Chicago → Dallas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "53' dry van · pickup tomorrow 08:00 · Joliet empty"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid grid-cols-3 gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-elevated p-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: "All-in"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-display text-lg font-semibold",
							children: "$2,550"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-elevated p-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: "Per mile"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-display text-lg font-semibold",
							children: "$2.10"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md bg-elevated p-3 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: "Miles"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-display text-lg font-semibold",
							children: "1,214"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-sm leading-relaxed text-muted",
				children: "Broker already agreed. You still have to accept. No DAT refresh. No hold music."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => openLead("hero-accept"),
					children: "Accept load"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => openLead("hero-pass"),
					children: "Pass"
				})]
			})
		]
	});
}
var Dialog = Dialog$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-bg/80 data-[state=open]:animate-[rise-in_250ms_ease-out] data-[state=closed]:opacity-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(100%-1.5rem,32rem)] -translate-x-1/2 -translate-y-1/2 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] focus:outline-none data-[state=open]:animate-[rise-in_250ms_ease-out]", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			className: "absolute top-4 right-4 inline-flex size-11 items-center justify-center rounded-sm text-muted transition-colors duration-150 hover:bg-elevated hover:text-fg",
			"aria-label": "Close",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
		})]
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-xl font-semibold tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-1.5 text-sm leading-relaxed text-muted", className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md bg-elevated px-3.5 text-[0.9375rem] text-fg shadow-[var(--shadow-border)] placeholder:text-subtle transition-[box-shadow] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
		className: cn("text-sm font-medium text-muted", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-24 w-full rounded-md bg-elevated px-3.5 py-2.5 text-[0.9375rem] text-fg shadow-[var(--shadow-border)] placeholder:text-subtle transition-[box-shadow] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", className),
		...props
	});
}
var KEY = "fleetworks.leads.v1";
function readLeads() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function saveLead(lead) {
	const next = {
		...lead,
		id: crypto.randomUUID(),
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	const all = [next, ...readLeads()];
	window.localStorage.setItem(KEY, JSON.stringify(all));
	return next;
}
var schema = object({
	name: string().min(2, "Name is required"),
	email: email("Enter a work email"),
	phone: string().min(7, "Phone is required"),
	company: string().min(2, "Company is required"),
	role: _enum(["carrier", "broker"]),
	mcDot: string().optional(),
	lanes: string().optional()
});
function LeadDialog() {
	const open = useApp((s) => s.leadOpen);
	const source = useApp((s) => s.leadSource);
	const audience = useApp((s) => s.audience);
	const closeLead = useApp((s) => s.closeLead);
	const [done, setDone] = (0, import_react.useState)(false);
	const form = useForm({
		resolver: u(schema),
		defaultValues: {
			name: "",
			email: "",
			phone: "",
			company: "",
			role: audience,
			mcDot: "",
			lanes: ""
		}
	});
	(0, import_react.useEffect)(() => {
		if (open) {
			setDone(false);
			form.reset({
				name: "",
				email: "",
				phone: "",
				company: "",
				role: audience,
				mcDot: "",
				lanes: ""
			});
		}
	}, [
		open,
		audience,
		form
	]);
	const isCarrier = form.watch("role") === "carrier";
	function onSubmit(values) {
		saveLead({
			...values,
			mcDot: values.mcDot ?? "",
			lanes: values.lanes ?? "",
			source
		});
		setDone(true);
		toast.success(isCarrier ? "You're in. Carrier ops will reach out to confirm lanes and equipment." : "Walkthrough requested. We'll come back with a time that fits your desk.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !v ? closeLead() : null,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Success, {
			role: form.getValues("role"),
			onClose: closeLead
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: isCarrier ? "Get your first load offers" : "Book a coverage walkthrough" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: isCarrier ? "Two minutes. A U.S. relationship manager confirms your truck, then we start calling." : "Thirty minutes. Your lanes, your rails, your TMS. No slide deck." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 grid gap-3.5",
				onSubmit: form.handleSubmit(onSubmit),
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						error: form.formState.errors.name?.message,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoComplete: "name",
							...form.register("name")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3.5 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Work email",
							error: form.formState.errors.email?.message,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								autoComplete: "email",
								...form.register("email")
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Mobile",
							error: form.formState.errors.phone?.message,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "tel",
								autoComplete: "tel",
								...form.register("phone")
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Company",
						error: form.formState.errors.company?.message,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoComplete: "organization",
							...form.register("company")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-2 text-sm font-medium text-muted",
						children: "I am a"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: ["carrier", "broker"].map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 cursor-pointer items-center justify-center rounded-md bg-elevated text-sm font-medium capitalize shadow-[var(--shadow-border)] has-[:checked]:bg-accent has-[:checked]:text-accent-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								value: role,
								className: "sr-only",
								...form.register("role")
							}), role]
						}, role))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: isCarrier ? "MC or DOT (optional)" : "TMS (optional)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: isCarrier ? "MC 123456" : "Aljex, McLeod, Turvo…",
							...form.register("mcDot")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: isCarrier ? "Lanes and equipment (optional)" : "Where coverage hurts (optional)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							placeholder: isCarrier ? "Midwest dry van, home weekends, avoid that South Dallas receiver…" : "Reefer into Florida Fridays, inbound after 6pm…",
							...form.register("lanes")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "mt-1 w-full",
						size: "lg",
						children: isCarrier ? "Start calling for my truck" : "Request the walkthrough"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-xs text-subtle",
						children: [
							"Prefer a person now? Call or text",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "text-muted underline-offset-2 hover:underline",
								href: `tel:${PHONE_TEL}`,
								children: PHONE_DISPLAY
							}),
							isCarrier ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								" ",
								"or email",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-muted underline-offset-2 hover:underline",
									href: `mailto:${CARRIER_EMAIL}`,
									children: CARRIER_EMAIL
								})
							] }) : null,
							"."
						]
					})
				]
			})
		] }) })
	});
}
function Field({ label, error, children }) {
	const id = (0, import_react.useId)();
	const control = (0, import_react.isValidElement)(children) ? (0, import_react.cloneElement)(children, { id }) : children;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: id,
				children: label
			}),
			control,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-danger",
				children: error
			}) : null
		]
	});
}
function Success({ role, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "You're on the list." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: role === "carrier" ? "Carrier ops will confirm equipment and lanes, then the agent starts working brokers. Keep your phone on." : "We'll send a calendar hold for a 30-minute coverage walkthrough on your actual freight — not a generic demo." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-6 w-full",
			onClick: onClose,
			children: "Back to the site"
		})
	] });
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-2.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 32 32",
			className: "size-7",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-accent"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M9 9.5h9.2c3.2 0 5.3 1.9 5.3 4.7 0 2.1-1.2 3.6-3.2 4.2L23.8 22.5h-3.4l-3.2-3.9H12.2V22.5H9V9.5Zm3.2 2.4v4.3h5.6c1.7 0 2.7-.9 2.7-2.2s-1-2.1-2.7-2.1H12.2Z",
				className: "fill-accent-fg"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-[1.05rem] font-semibold tracking-tight",
			children: "FleetWorks"
		})]
	});
}
function Nav() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const audience = useApp((s) => s.audience);
	const openLead = useApp((s) => s.openLead);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-line/80 bg-bg/80 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#top",
					className: "shrink-0",
					"aria-label": "FleetWorks home",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-7 md:flex",
					children: navLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						className: "text-sm font-medium text-muted transition-colors duration-150 hover:text-fg",
						children: link.label
					}, link.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center gap-3 md:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudienceToggle, { className: "w-48" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => openLead("nav"),
						size: "sm",
						children: audience === "carrier" ? "Get offers" : "Book a walkthrough"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center rounded-sm md:hidden",
					"aria-label": open ? "Close menu" : "Open menu",
					onClick: () => setOpen((v) => !v),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("border-t border-line bg-surface px-4 py-4 md:hidden", open ? "block" : "hidden"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex flex-col gap-1",
				children: navLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: link.href,
					onClick: () => setOpen(false),
					className: "rounded-sm px-2 py-3 text-base text-fg",
					children: link.label
				}, link.href))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudienceToggle, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						setOpen(false);
						openLead("nav-mobile");
					},
					children: audience === "carrier" ? "Get my first load offers" : "Book a coverage walkthrough"
				})]
			})]
		})]
	});
}
var Accordion = Root2;
function AccordionItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
		className: cn("border-b border-line", className),
		...props
	});
}
function AccordionTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
		className: "flex",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
			className: cn("flex flex-1 items-center justify-between gap-4 py-5 text-left font-display text-lg font-medium tracking-tight transition-colors duration-150 hover:text-accent [&[data-state=open]>svg]:rotate-180", className),
			...props,
			children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 shrink-0 text-muted transition-transform duration-250 ease-[cubic-bezier(0.22,1,0.36,1)]" })]
		})
	});
}
function AccordionContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		className: "overflow-hidden text-muted data-[state=closed]:animate-none",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("pb-5 text-[0.975rem] leading-relaxed", className),
			children
		})
	});
}
function Problem() {
	const { problem } = copyFor(useApp((s) => s.audience));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 px-4 py-20 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
					children: problem.kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: problem.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-lg leading-relaxed text-muted",
					children: problem.body
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "grid gap-4",
				children: problem.points.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-accent",
							children: ["0", i + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-display text-xl font-semibold tracking-tight",
							children: p.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[0.975rem] leading-relaxed text-muted",
							children: p.body
						})
					]
				}, p.title))
			})]
		})
	});
}
function Demo() {
	const audience = useApp((s) => s.audience);
	const { demo } = copyFor(audience);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [index, setIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		setPlaying(false);
		setIndex(0);
	}, [audience]);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		if (index >= demo.length - 1) {
			setPlaying(false);
			return;
		}
		const t = window.setTimeout(() => setIndex((i) => i + 1), 2400);
		return () => window.clearTimeout(t);
	}, [
		playing,
		index,
		demo.length
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "demo",
		className: "border-t border-line bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-10 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
					children: "Listen to a negotiation"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "This is the call you never have to make."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-lg leading-relaxed text-muted",
					children: audience === "carrier" ? "An agent that knows trucking language, your empty time, and today's market — then brings you a rate a broker already agreed to." : "An agent that works your buy rail, cites live SONAR, vets the MC in-conversation, and only wakes a human when the load is actually coverable."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-subtle",
					children: "Composite of a typical Chicago–Dallas dry van. Not a recorded customer call."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-bg p-5 shadow-[var(--shadow-border)] sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								if (index >= demo.length - 1) setIndex(0);
								setPlaying((p) => !p);
							},
							className: "inline-flex size-11 items-center justify-center rounded-full bg-accent text-accent-fg",
							"aria-label": playing ? "Pause demo" : "Play demo",
							children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-sm font-semibold",
							children: "CHI → DAL · 53' van"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Voice · SMS · Email"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waveform, { active: playing })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 grid gap-3",
					children: demo.map((turn, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("rounded-md px-3.5 py-3 text-sm leading-relaxed transition-[opacity,transform] duration-250 ease-out", i <= index ? "bg-elevated text-fg opacity-100" : "bg-transparent text-subtle opacity-40", turn.who === "ai" ? "mr-6" : "ml-6"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 font-mono text-[0.65rem] tracking-wide text-accent uppercase",
							children: turn.name
						}), turn.text]
					}, `${turn.name}-${i}`))
				})]
			})]
		})
	});
}
function Waveform({ active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-8 items-end gap-0.5",
		"aria-hidden": true,
		children: Array.from({ length: 12 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "w-0.5 origin-bottom rounded-full bg-accent",
			style: {
				height: "100%",
				animation: active ? `wave 0.9s ease-in-out ${i * .07}s infinite` : "none",
				transform: active ? void 0 : `scaleY(${.25 + i % 4 * .15})`
			}
		}, i))
	});
}
function How() {
	const { how } = copyFor(useApp((s) => s.audience));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "how",
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
					children: "How it works"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-xl font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "Three moves. Then freight moves."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-12 grid gap-5 md:grid-cols-3",
					children: how.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg bg-surface p-6 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-accent",
								children: step.step
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-display text-xl font-semibold tracking-tight",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-[0.975rem] leading-relaxed text-muted",
								children: step.body
							})
						]
					}, step.step))
				})
			]
		})
	});
}
function Product() {
	const audience = useApp((s) => s.audience);
	const { features } = copyFor(audience);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "product",
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-10 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: audience === "carrier" ? "/images/cab-night.jpg" : "/images/dock-dawn.jpg",
					alt: audience === "carrier" ? "Night highway through a rain-speckled windshield" : "Trailer at a loading dock at dawn",
					className: "img-frame aspect-[3/2] h-full w-full object-cover"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
					children: "Built for the phone, not a dashboard"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: audience === "carrier" ? "An always-on dispatcher that already knows your truck." : "A carrier rep that already knows 29,000 trucks."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 grid gap-6",
					children: features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-accent/15 text-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-lg font-semibold tracking-tight",
							children: f.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[0.975rem] leading-relaxed text-muted",
							children: f.body
						})] })]
					}, f.title))
				})
			] })]
		})
	});
}
function Results() {
	const { results } = copyFor(useApp((s) => s.audience));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "proof",
		className: "border-t border-line bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
					children: "What changes on the P&L"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-2xl font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "Numbers from the road, not a lab."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-5 md:grid-cols-3",
					children: results.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-lg bg-bg p-6 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-4xl font-semibold tracking-tight text-accent",
								children: r.stat
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-display text-lg font-semibold tracking-tight",
								children: r.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: r.note
							})
						]
					}, r.label))
				})
			]
		})
	});
}
function Stories() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
					children: "From owners who still drive"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "They used to refresh the board. They don't."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
					children: stories.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "flex flex-col justify-between rounded-lg bg-surface p-6 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "text-[1.05rem] leading-relaxed",
							children: [
								"“",
								s.quote,
								"”"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
							className: "mt-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display font-semibold tracking-tight",
								children: s.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: s.role
							})]
						})]
					}, s.name))
				})
			]
		})
	});
}
function Offer() {
	const audience = useApp((s) => s.audience);
	const openLead = useApp((s) => s.openLead);
	const { offer } = copyFor(audience);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-10 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
					children: "The offer"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: offer.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-lg leading-relaxed text-muted",
					children: offer.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 grid gap-3",
					children: offer.bullets.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 text-[0.975rem] leading-relaxed",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-1 size-4 shrink-0 text-accent" }), b]
					}, b))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "mt-8",
					size: "lg",
					onClick: () => openLead("offer"),
					children: [offer.cta, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: audience === "carrier" ? "/images/dock-dawn.jpg" : "/images/cab-night.jpg",
					alt: "",
					className: "img-frame aspect-[3/2] w-full object-cover"
				})
			})]
		})
	});
}
function Faq() {
	const { faqs } = copyFor(useApp((s) => s.audience));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "faq",
		className: "border-t border-line bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 py-20 sm:px-6 lg:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.7rem] font-medium tracking-[0.18em] text-accent uppercase",
					children: "Questions operators actually ask"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "Straight answers."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
					type: "single",
					collapsible: true,
					className: "mt-10",
					children: faqs.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
						value: `q-${i}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, { children: item.q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, { children: item.a })]
					}, item.q))
				})
			]
		})
	});
}
function Cta() {
	const audience = useApp((s) => s.audience);
	const openLead = useApp((s) => s.openLead);
	const { cta } = copyFor(audience);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 py-20 text-center sm:px-6 lg:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: cta.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-5 max-w-xl text-lg leading-relaxed text-muted",
					children: cta.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						onClick: () => openLead("final"),
						children: [cta.primary, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `tel:${PHONE_TEL}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {}),
								"Call ",
								PHONE_DISPLAY
							]
						})
					})]
				})
			]
		})
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-8 px-4 py-12 sm:px-6 md:flex-row md:items-start md:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg font-semibold tracking-tight",
				children: "FleetWorks"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-sm text-sm leading-relaxed text-muted",
				children: [
					"Load board on autopilot for carriers and brokers. Backed by",
					" ",
					investors.slice(0, -1).join(", "),
					", and ",
					investors[investors.length - 1],
					"."
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-10 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-fg",
						children: "Carriers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "mt-2 block text-muted hover:text-fg",
						href: `tel:${PHONE_TEL}`,
						children: PHONE_DISPLAY
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "mt-1 block text-muted hover:text-fg",
						href: `mailto:${CARRIER_EMAIL}`,
						children: CARRIER_EMAIL
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-fg",
						children: "Company"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "mt-2 block text-muted hover:text-fg",
						href: "https://www.fleetworks.ai/about",
						target: "_blank",
						rel: "noreferrer",
						children: "About"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "mt-1 block text-muted hover:text-fg",
						href: "https://www.fleetworks.ai/",
						target: "_blank",
						rel: "noreferrer",
						children: "fleetworks.ai"
					})
				] })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto max-w-6xl px-4 py-5 text-xs text-subtle sm:px-6",
				children: "FleetWorks. San Francisco. Not affiliated with DAT, Truckstop, or SONAR beyond published partnerships. You still choose every load."
			})
		})]
	});
}
function StickyCta() {
	const audience = useApp((s) => s.audience);
	const openLead = useApp((s) => s.openLead);
	const [show, setShow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		function onScroll() {
			setShow(window.scrollY > 520);
		}
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	if (!show) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 p-3 backdrop-blur-md md:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "w-full",
			onClick: () => openLead("sticky"),
			children: audience === "carrier" ? "Get my first load offers" : "Book a coverage walkthrough"
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "bg-bg pb-16 text-fg md:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Problem, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Demo, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(How, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Product, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stories, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Offer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Faq, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cta, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeadDialog, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyCta, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-right",
				toastOptions: { className: "bg-surface text-fg border-line font-sans" }
			})
		]
	});
}
//#endregion
export { Home as component };
